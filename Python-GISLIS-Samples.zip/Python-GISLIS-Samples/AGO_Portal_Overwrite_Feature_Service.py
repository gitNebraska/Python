import arcpy
from arcgis.gis import GIS,Item,User
from datetime import datetime as dt
import getpass,sys,os,shutil

def copyPRJ(src,dst):
    if not os.path.exists(dst):
        shutil.copyfile(src,dst)

try:
    #Set variables
    portal = "https://portal.myportal.org/portal"
    gis = GIS(portal,username="my_user",password="my_password")
    user = User(gis,'some_user',None)
    NAME = "My Favorite Feature Service"
    prjSrc = r"C:\Users\{0}\Documents\Staging\FS_Overwrite_Pro_Project.aprx".format(getpass.getuser())
    prjPath = r"C:\Users\{0}\Documents\Production\FS_Final_Pro_Project.aprx".format(getpass.getuser())
    sd_fs_name = NAME
    sddraft = os.path.join(r"C:\Users\{0}\Documents\Production\my_favorite_feature_service".format(getpass.getuser()),NAME+".sddraft")
    sd = os.path.join(r"C:\Users\{0}\Documents\Production\my_favorite_feature_service".format(getpass.getuser()),NAME+".sd")

    #Prepare workspace
    arcpy.env.workspace = r"C:\Users\{0}\Documents\Production".format(getpass.getuser())
    arcpy.env.overwriteOutput = True
    copyPRJ(prjSrc,prjPath)
    prj = arcpy.mp.ArcGISProject(prjPath)
    mp = prj.listMaps()[0]
    
    #Apply metadata
    sharing_draft = mp.getWebLayerSharingDraft("HOSTING_SERVER","FEATURE","My Favorite Feature Service")
    sharing_draft.summary = "My favorite service summary."
    sharing_draft.tag = "favorite,service"
    sharing_draft.description = "Last updated: {0}".format(dt.now().strftime("%Y-%m-%d"))
    sharing_draft.credits = "None"
    sharing_draft.serviceName = 'My Favorite Feature Service'

    #Publish service    
    sharing_draft.exportToSDDraft(sddraft)
    arcpy.StageService_server(sddraft,sd)
    sdItem = gis.content.search("title:My Favorite Feature Service",item_type="Service Definition")[0]
    sdItem.update(data=sd)
    fs=sdItem.publish(overwrite=True)

except Exception:
    print(str(sys.exc_info()[1]))
