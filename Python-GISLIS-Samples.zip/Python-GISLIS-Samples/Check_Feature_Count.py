import arcpy,smtplib

step = ''
error = ''

#Define Function to Send Email
def sendError(error,body,message,stat,send):
    print "\tSending results in email."
    fromaddr = 'from@email.com'
    toaddrs = send
    username = 'from@email.com'
    password = 'password'
    server = smtplib.SMTP('smtp.gmail.com:587')
    server.starttls()
    server.login(username,password)
    server.sendmail(fromaddr,toaddrs,message)
    print "\tMail Sent!"
    server.quit()
    if stat == 'y':
        sys.exit(0)

try:
    #Set variables
    step = "setting variables...";print(step)
    FS_cloud = "Database Connections\\cloud_database.sde\\database.GIS.FeatureService"
    FS_local = "Database Connections\\local_database.sde\\database.GIS.FeatureService"

    #Count Features
    step = "counting features on 91...";print(step)
    Count_cloud = int(arcpy.GetCount_management(FS_cloud).getOutput(0))

    step = "counting Code_Enforcement features on dcgissql01...";print(step)
    Count_local = int(arcpy.GetCount_management(FS_local).getOutput(0))

    #Compare Features
    if Count_lcoud == Count_local:
        print("No discrepancy detected.")
    else:
        error = ''
        body = "Discrepancy detected in Feature Service data between cloud and local. \n\nFeature count on cloud:  "+str(Count_91)+"\n\nFeature count on dcgissql01:  "+str(Count_dcgis)+"\n\nPlease review the data and resolve discrepancies ASAP."
        message = "Subject: %s\n\n%s" % ('ATTENTION - Feature Service data is out of sync between cloud and local',body)
        stat = 'y'
        send = 'manager@email.com'
        sendError(error,body,message,stat,send)

except Exception as e:
    error = step + "\nError: " + e.message; print error
    body = "Check_Feature_Count.py failed while " + error
    message = 'Subject: %s\n\n%s' % ("Check_Feature_Count.py Failed",body)
    stat = 'y'
    send = 'manager@email.com'
    sendError(error,body,message,stat,send)

    

    
    
