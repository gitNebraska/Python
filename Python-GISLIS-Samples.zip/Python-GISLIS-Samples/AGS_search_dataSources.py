import json,os,csv,getpass
import xml.etree.ElementTree as ET

######
directory = r'D:\arcgisserver\config-store\services'
text_output = 'C:/Users/' + getpass.getuser() + '/Desktop/service_list.txt'
######

def returnLAYER_list(user_input):
    culprit_list = []
    path = ''
    db = ''
    user = ''
    if ',' in user_input:
        user_input = user_input.replace(' ','').split(',')
        user_input_text = ', '.join(user_input)
    else:
        user_input_text = str(user_input)
    secsearchdir = []
    for subdir,dirs,files in os.walk(directory):
        for file in files:
            if 'rlock' not in str(file):
                if 'MapServer.sec' in str(file):
                    secsearchdir.append(os.path.join(subdir,file))

    sec_dict={}
    for each in secsearchdir:
        each_name = each[each.find('.')+1:-14]
        tree = ET.parse(each)
        root = tree.getroot()
        dict_list = []
        for child in root:
            for each in child:
                if each.attrib['isAllowed']=='true':
                    dict_list.append(each.attrib['principal'])
        sec_dict[each_name]=dict_list

    searchdir = []
    for subdir,dirs,files in os.walk(directory):
        for file in files:
            if 'rlock' not in str(file):
                if 'MapServer.json' in str(file):
                    if 'DynamicMappingHost' not in str(file):
                        searchdir.append(os.path.join(subdir,file))

    for each in searchdir:
        each_xml = each[:each.rfind('\\')]+'\\esriinfo\\manifest\\manifest.xml'
        tree = ET.parse(each_xml)
        root = tree.getroot()
        folder_service = each[len(directory)+1:each.rfind('\\')-10]
        service_name = each[each.rfind('\\')+1:-15]
        folder = ''
        if '\\' in folder_service:
            folder = folder_service[:folder_service.find('\\')]
        else:
            folder = 'Root'
        culprit_header = '\n{0}/{1}'.format(folder,service_name)
        for child in root:
            if child.tag == 'Databases':
                for each in child:
                    if each.tag == 'SVCDatabase':
                        for element in each:
                            if element.tag == 'Datasets':
                                for dataset in element:
                                    if dataset.tag == 'SVCDataset':
                                        for item in dataset:
                                            if item.tag == 'Name':
                                                path = dataset.find('OnPremisePath')
                                                if path is not None:
                                                    path = path.text
                                                    if '.gdb' in path:
                                                        user = 'N\\A'
                                                        db3 = path[path.rfind('\\')+1:]+'.gdb'
                                                    else:
                                                        db1 = path[path.find('\\'):path.find('.sde')]
                                                        user = db1[db1.rfind('.')+1:]
                                                        db2 = db1[:db1.rfind('.')]
                                                        db3 = db2[db2.rfind('.')+1:]
                                                if isinstance(user_input,list):
                                                    for i in user_input:
                                                        if item.text.lower() == i:
                                                            if any(culprit_header in s for s in culprit_list):
                                                                culprit_list.append('\t{0} (db: {1}, user: {2})'.format(item.text,db3,user))
                                                            else:
                                                                culprit_list.append('{0}\n\t{1} (db: {2}, user: {3})'.format(culprit_header,item.text,db3,user))
                                                else:
                                                    if item.text.lower() == user_input:
                                                        culprit_list.append('{0} - {1} (db: {2}, user: {3})'.format(culprit_header,item.text,db3,user))
                                                        

    with open(text_output, 'w') as textfile:
        if len(culprit_list) < 1:
            textfile.write('None')
        else:
            for culprit in culprit_list:
                textfile.write(str(culprit)+'\n')
    new_name = 'C:/Users/' + getpass.getuser() + '/Desktop/Services with ' + user_input_text + '.txt'
    if os.path.exists(new_name):
        os.remove(new_name)
    os.rename(text_output,new_name)
    os.startfile(new_name)

returnLAYER_list(raw_input("What are you looking for?\n(Separate with comma): ").lower())
    
