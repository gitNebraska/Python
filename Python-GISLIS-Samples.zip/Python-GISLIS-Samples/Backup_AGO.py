# This script is designed to back up all feature services
# in a particular folder. It can be modified to backup other
# types of content. It can also be modified to backup content
# in multiple folders, multiple users, etc.

from arcgis.gis import GIS,Item,User
from datetime import datetime as dt
import getpass
import os,sys

try:
    #Set login information for AGO
    username = "your_user"
    password = "your_password"

    #Set GIS environment
    print('signing into AGO')
    gis=GIS(url="https://your_organization.maps.arcgis.com",username=username,password=password)

    #Assign User as 'citizen_reporter' to gain work with citizen reporter's content
    user = User(gis,username,None)
    user_folder = 'some_folder'

    #Set datestamp variable
    datestamp = dt.now().strftime("%Y%m%d")    

    #Assign path for backup folder; create it if it doesn't exist
    output_backup_folder = '{0}_{1}_AGObackup_'.format(username,user_folder) + datestamp
    output_backup_folder_path = os.path.join(r'C:\Users\{0}\Documents\Archive'.format(getpass.getuser()),output_backup_folder)
    print('checking for backup folder')
    if not os.path.exists(output_backup_folder_path):
        print('creating backup folder')
        os.makedirs(output_backup_folder_path)

    ###Assemble list of folders for citizen_reporter user
    print('obtain list of user\'s folders')
    folder_list = user.folders

    #Go to 'some_folder' folder, then export and download all items
    print('finding \'{0}\' folder'.format(user_folder))
    for folder in folder_list:
        if folder['title'] == user_folder:
            print('obtain list of items in folder')
            item_list = user.items(folder)
            for item in item_list:
                item_name = str(item['title']) + '_' + datestamp
                print('checking if item is a feature service')
                if item['type'] == 'Feature Service':
                    print('exporting {0}'.format(item['title']))
                    item.export(item_name,'File Geodatabase', None, True)
                    gdb = gis.content.search(query = item_name)
                    print('downloading {0}'.format(item['title']))
                    gdb[0].download(output_backup_folder_path)
                    print('deleting {0}'.format(item['title']))
                    gdb[0].delete()
except Exception:
    print(sys.exc_info()[1])
