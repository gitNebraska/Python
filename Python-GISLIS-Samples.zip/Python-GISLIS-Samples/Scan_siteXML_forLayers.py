import os,getpass
import xml.etree.cElementTree as ET

######
directory = 'C:\\Program Files (x86)\\Latitude Geographics\\Geocortex Essentials\\Default\\REST Elements\\Sites'
text_output_location = 'C:/Users/' + getpass.getuser() + '/Desktop/'
######

def returnXML_list(directory,user_input):
    xml_list = []
    if ',' in user_input:
        user_input = user_input.replace(' ','').split(',')
        user_input_text = ', '.join(user_input)
    else:
        user_input_text = str(user_input)
    for folder in os.listdir(directory):
        #print(folder)
        foldername = os.path.join(directory,folder)
        if os.path.isdir(foldername):
            for filename in os.listdir(foldername):
                #print('\t'+filename)
                filepath = os.path.join(directory,foldername,filename)
                if os.path.isfile(filepath):
                    if filename.endswith('Site.xml'):
                        tree = ET.parse(filepath)
                        root = tree.getroot()
                        fileread=ET.tostring(root,encoding='utf8').decode('utf8').lower()
                        if isinstance(user_input,list):
                            for each in user_input:
                                line = str(folder) + ' (%s)' % (each)
                                #print(line)
                                if each in fileread:
                                    if line not in xml_list:
                                        xml_list.append(line)
                        else:
                            line = str(folder)
                            if user_input in fileread:
                                #print(line)
                                if line not in xml_list:
                                    xml_list.append(line)
    xml_list = sorted(list(set(xml_list)))
    #print xml_list
    text_output = text_output_location + 'xml_list.txt'
    with open(text_output, 'w') as textfile:
        if len(xml_list) < 1:
            textfile.write('None')
        else:
            for xml_file in xml_list:
                textfile.write(str(xml_file)+'\n')
    new_name = 'C:/Users/' + getpass.getuser() + '/Desktop/Sites with ' + user_input_text + '.txt'
    try:
        if os.path.exists(new_name):
            os.remove(new_name)
        os.rename(text_output,new_name)
        os.startfile(new_name)
    except:
        try:
            new_name = 'C:/Users/' + getpass.getuser() + '/Desktop/Sites with ' + user_input_text[:user_input_text.find('=')] + '.txt'
            if os.path.exists(new_name):
                os.remove(new_name)
            os.rename(text_output,new_name)
            os.startfile(new_name)
        except:
            os.startfile(text_output)

returnXML_list(directory,raw_input("What are you looking for?\nTry searching for a service name or a parameter...\nParameter Example: defaultallowsymbolization=\"true\"\n(Separate multiple search items with comma): ").lower())
