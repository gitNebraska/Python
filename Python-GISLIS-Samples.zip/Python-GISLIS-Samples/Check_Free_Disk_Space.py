#!/usr/bin/env python

"""
Return disk usage statistics about the given path as a (total, used, free)
namedtuple.  Values are expressed in bytes.
"""
# Author: Giampaolo Rodola' <g.rodola [AT] gmail [DOT] com>
# License: MIT

# Modified by DCGIS

import os
import collections,smtp

_ntuple_diskusage = collections.namedtuple('usage', 'total used free')

import ctypes
import sys

def sendError(error,body,message,stat,send):
    print "\tSending results in email."
    fromaddr = 'from@email.com'
    toaddrs = send
    username = 'from@email.com'
    password = 'password'
    server = smtplib.SMTP('smtp.gmail.com:587')
    server.starttls()
    server.login(username,password)
    server.sendmail(fromaddr,toaddrs,message)
    print "\tMail Sent!"
    server.quit()
    if stat == 'y':
        sys.exit(0)

def disk_usage(path):
    _, total, free = ctypes.c_ulonglong(), ctypes.c_ulonglong(), \
                       ctypes.c_ulonglong()
    if sys.version_info >= (3,) or isinstance(path, unicode):
        fun = ctypes.windll.kernel32.GetDiskFreeSpaceExW
    else:
        fun = ctypes.windll.kernel32.GetDiskFreeSpaceExA
    ret = fun(path, ctypes.byref(_), ctypes.byref(total), ctypes.byref(free))
    if ret == 0:
        raise ctypes.WinError()
    used = total.value - free.value
    return _ntuple_diskusage(total.value, used, free.value)


def bytes2human(n):
    symbols = ('KB', 'MB', 'GB', 'TB', 'P', 'E', 'Z', 'Y')
    prefix = {}
    for i, s in enumerate(symbols):
        prefix[s] = 1 << (i+1)*10
    for s in reversed(symbols):
        if n >= prefix[s]:
            value = float(n) / prefix[s]
            return '%.1f%s' % (value, s)
    return "%sB" % n

#disk_usage.__doc__ = __doc__

if __name__ == '__main__':
    free_space = bytes2human(disk_usage('C:').free)
    print free_space
    num = float(free_space[:-2])
    if num < 2:
        sendError('DISK SPACE LOW ON TASK MACHINE',
                    'Only %s free space remaining on C: drive of Task Machine'%free_space,'\nRESOLVE IMMEDIATELY',
                    'manager@email.com')
