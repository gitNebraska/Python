import os,datetime

def getTasks(name):
    count = 0
    r = os.popen('tasklist /v').read().strip().split('\n')
    print('%s total tasks are running' % (len(r)))
    for i in range(len(r)):
        if name in r[i]:
            count += 1
    print('%d are ArcSOC processes' % count)
    now = datetime.datetime.now()
    return str(count)+ ',' + str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M"))

with open('ArcSOC_List.csv','r+') as f:
    content = f.read()
    f.seek(0)
    f.write(getTasks('ArcSOC.exe').rstrip('\r\n') + '\n' + content)
