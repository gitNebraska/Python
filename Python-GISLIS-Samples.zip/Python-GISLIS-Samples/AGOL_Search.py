import getpass
from arcgis.gis import GIS
from arcgis.mapping import WebMap

def defineGIS(user,password):
    return GIS(username=user,password=password)

def defineQuery(yn):
    if yn == 'y':
        query = input('Which username? ')
        return query

def searchAGOL(gis,url,query):
    if ',' in url:
        url = url.replace(' ','').split(',')
    for user in gis.users.search(query,max_users=1000):
        print("checking "+str(user['username']+"'s content..."))
        try:
            folder_list = user.folders
            i=0
            while i < len(folder_list):
                #print(folder_list[i]['title'])
                item_list = user.items(folder_list[i])
                j = 0
                while j < len(item_list):
                    if item_list[j]['type'] == 'Web Map':
                        wm_item = item_list[j]
                        web_map_obj = WebMap(wm_item)
                        for each in web_map_obj.layers:
                            if isinstance(url,list):
                                for thing in url:
                                    if 'url' in each:
                                        if thing.lower() in each["url"].lower():
                                            print("\t" + str(item_list[j]["title"]) + " uses "+str(each["url"]))
                            else:
                                if 'url' in each:
                                    if url.lower() in each["url"].lower():
                                        print("\t"+str(item_list[j]["title"]) + " uses "+str(each["url"]))
                    j+=1
                i+=1
        except:
            e = sys.exc_info()[1]
            error = str(e)
            print('error on ' + str(user['username'])+'\n'+error)

user_info = defineGIS(input('User: '),getpass.getpass('Password: '))
url = input('Enter the URL (or part of URL) of a service\nto search for it in web maps (separate multiple by comma): ')
query = defineQuery(input('Would you like to query a specific user\'s content? (y/n): '))

searchAGOL(user_info,url,query)
