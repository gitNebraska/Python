print "Importing modules..."
# Import arcpy module
import arcpy,os,sys,time,getpass
import xml.dom.minidom as DOM

#set variables for error message
error = ''
step = ''

print 'Start time: ' + time.strftime('%H:%M:%S')

#define Date function
def getDate():
    t = time.strftime
    hms = '%m/%d/%Y'
    return 'Locator updated ' + t(hms)

# Set environment to locators folder
step = "Setting environment..."
print step
arcpy.env.workspace = r'C:\Locators\'

# Set Locator variables
step = "Setting locator variables..."
print step
AP = 'Address_Points'
SC = 'Street_Centerlines'
AP_SC = 'Address_Points_Streets_Composite'

locators = [AP,SC,AP_SC]

def publishLocator(loc):
    step = "Deleting previous " + loc + " serviceDefinition file...";print(step)
    arcpy.Delete_management(serviceDefinition)
    step = "Creating sdDraft for " + loc + " locator...";print(step)
    arcpy.CreateGeocodeSDDraft(geocoder, sdDraft, serviceName, 'FROM_CONNECTION_FILE',ags,'','Geocoders',note,loc,supported_operations='SUGGEST')
    step = "Staging service for " + loc + " locator...";print(step)
    arcpy.StageService_server(sdDraft, serviceDefinition)
    step = "Uploading service definition for " + loc + " locator...";print(step)
    arcpy.UploadServiceDefinition_server(serviceDefinition,ags,'','','FROM_SERVICE_DEFINITION','','','','','','','')

try:

    # Loop through address locators
    step = 'beginning to loop through address locators...'
    print step
    for loc in locators:
        step = 'setting variables for rebuilding and republishing locators...';print(step)
        serviceName = loc
        serviceDefinition =r'C:\Locators\' + loc + '.sd'
        sdDraft = loc + '.sddraft'
        geocoder = r'C:\Locators\' + loc + '.loc'
        ags = r'C:\Users\{0}\AppData\Roaming\ESRI\Desktop10.6\ArcCatalog\arcgis on your.ags.server.org (admin).ags'.format(getpass.getuser())
        note = getDate()

        #Check whether locator is composite. If not, rebuild it.
        step = 'checking whether ' + loc + ' locator is composite...';print(step)
        if 'Composite' not in loc:
            arcpy.RebuildAddressLocator_geocoding(loc)

except Exception as e:
    print(e.message)

print 'End time: ' + time.strftime('%H:%M:%S')



