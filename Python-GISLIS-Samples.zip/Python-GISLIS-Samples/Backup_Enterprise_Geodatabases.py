# This script is used to backup Enterprise Geodatabases to s3. Must be used in conjunction with
# Backup_Enterprise_Geodatabases_dcgissql01.bat in order to work.  The batch file contains the commands
# necessary to perform the upload to s3 using the Amazon CLI. The batch file must be run
# from the 'gistask' account because that's where the CLI credentials are stored.
# Created: 01/11/2019

print "importing modules..."
import arcpy,os,datetime,zipfile,time,shutil

exclusion_list = ['fcs','not','to','back','up']

def zip(src):
    zf = zipfile.ZipFile("%s.zip" % (src),"w", zipfile.ZIP_DEFLATED,allowZip64=True)
    abs_src = os.path.abspath(src)
    for dirname,subdirs,files in os.walk(src):
        for filename in files:
            absname = os.path.abspath(os.path.join(dirname,filename))
            arcname = absname[len(abs_src)+1:]
            print 'zipping %s as %s' % (os.path.join(dirname,filename),arcname)
            zf.write(absname,arcname)
    zf.close()

    #Define function to procure date for Backup output
step = 'defining todayCalc()...';print(step)
def todayCalc():
    date = datetime.date.today()
    month = str(date.month)
    if len(month) == 1:
        month = '0'+ month
    day = str(date.day)
    if len(day) == 1:
        day = '0' + day
    today = str(date.year)+month+day
    return today
today = todayCalc()

### Define Databases for back up
databases = ['public_works','planning','vector','parks','public_safety','traffic','sewer']
###

try:
    print("creating backup directory...")
    backup_dir = "Enterprise_Geodatabases_Archive_" + today
    backup_dir_path = os.path.join(r'C:\Users\{0}\Documents\Archive'.format(getpass.getuser()),backup_dir)
    if os.path.exists(backup_dir_path):
        print("removing dir...")
        shutil.rmtree(backup_dir_path)
    print("making dir...")
    os.makedirs(backup_dir_path)
    for db in databases:
        print("creating backup gdb for {0}...".format(db))
        out_folder_path = backup_dir_path
        backup_gdb = db + "_" + today
        backup_gdb_path = out_folder_path + "\\" + backup_gdb + ".gdb"
        if not os.path.exists(backup_gdb_path):
            arcpy.CreateFileGDB_management(out_folder_path,backup_gdb)
        else:
            arcpy.Delete_management(backup_gdb_path)
    
        in_gdb = "Database Connections\\dcgissql01.{0}.gis.sde".format(db)
        
        print("setting workspace...")
        arcpy.env.maintainAttachments = False #This parameter does not work with arcpy.Copy_management
        arcpy.env.workspace = in_gdb

        print("defining datasets...")
        datasets = arcpy.ListDatasets()
        featureclasses = arcpy.ListFeatureClasses()
        tables = arcpy.ListTables()

        if len(datasets)>0:
            print("backing up {0} feature datasets...".format(db))
            for ds in datasets:
                try:
                    print(ds)
                    replace_var = db + ".GIS."
                    ds_out_path = backup_gdb_path + "\\" + str(ds).replace(replace_var,"")
                    ds_out = str(ds).replace(replace_var,"")
                    fc_exists = arcpy.Exists(ds_out_path)
                    if fc_exists:
                        print("\t\t{0} feature dataset already exists in backup gdb".format(ds))
                    else:
                        print("\tPreserving {0}".format(ds))
                        arcpy.Copy_management(ds,ds_out_path)
                except Exception:
                    print(sys.exc_info()[1])
                    
        step = "backing up feature classes...";print(step)
        for fc in featureclasses:
            try:
                replace_var = db + ".GIS."
                fc_out_path = backup_gdb_path + "\\" + str(fc).replace(replace_var,"")
                fc_out = str(fc).replace(".gis.",".GIS.").replace(replace_var,"")
                fc_exists = arcpy.Exists(fc_out_path)
                if fc_exists:
                    print("\t\t{0} already exists in backup gdb".format(fc))
                else:
                    if fc_out in exclusion_list:
                        print("\t\t"+fc_out+" purposely excluded...")
                    else:
                        print("\tPreserving {0} ({1})".format(fc,fc_out))
                        arcpy.FeatureClassToFeatureClass_conversion(fc,backup_gdb_path,fc_out)
            except Exception:
                print(sys.exc_info()[1])
                
        step = "backing up tables...";print(step)
        for table in tables:
            if "__ATTACH" not in table:
                try:
                    replace_var = db + ".GIS."
                    table_out_path = backup_gdb_path + "\\" + str(table).replace(replace_var,"")
                    table_out = str(table).replace(replace_var,"")
                    table_exists = arcpy.Exists(table_out_path)
                    if table_exists:
                        print("\t\t{0} already exists in backup gdb".format(table))
                    else:
                        step = "\tPreserving " + table;print(step)
                        arcpy.TableToTable_conversion(table,backup_gdb_path,table_out)
                except Exception:
                    print(sys.exc_info()[1])        

    zip(out_folder_path)
    print("remove uncompressed files...")
    shutil.rmtree(backup_dir_path)
        
except Exception:
    print(sys.exc_info()[1])
