import arcpy,csv,operator,os,zipfile,subprocess,getpass,datetime,time,sys
from shutil import copy

def zip(src):
    zf = zipfile.ZipFile("%s.zip" % (src),"w", zipfile.ZIP_DEFLATED)
    abs_src = os.path.abspath(src)
    for dirname,subdirs,files in os.walk(src):
        for filename in files:
            absname = os.path.abspath(os.path.join(dirname,filename))
            arcname = absname[len(abs_src)+1:]
            print 'zipping %s as %s' % (os.path.join(dirname,filename),arcname)
            zf.write(absname,arcname)
    zf.close()

def getUserFolder(user):
    if user == 'jsmith':
        return 'John'
    elif user == 'tpayne':
        return 'Tom'
    elif user == 'mjohnson':
        return 'Mary'
    elif user == 'syoung':
        return 'Steve'

step = 'defining variables...';print step
user = getpass.getuser()
projects_folder = 'C:/Users/'+user+'/Documents/ArcGIS/Projects'
user_folder = getUserFolder(user)
backup_folder = 'X:/Archive/ArcGISPro_Projects/'+user_folder
date = datetime.datetime.now().strftime("%Y%m%d")

step = 'zipping projects folder for ' + user + '...';print step
zip(projects_folder)

step = 'deleting existing backup...';print step
current_time = time.time()
for the_file in os.listdir(backup_folder):
    the_file = os.path.join(backup_folder,the_file)
    st=os.stat(the_file)
    ctime=st.st_ctime
    print the_file
    duration = (current_time-ctime) // (24 * 3600)
    if duration >= 60:
        print duration
        os.remove(the_file)

step = 'copying backup file of projects folder to ' + backup_folder + '...';print step
backup_file = projects_folder + ".zip"
copy(backup_file,backup_folder)

step = 'renaming backup file with date stamp...';print step
archive_file = backup_folder + backup_file[backup_file.rfind('/'):]
new_name = archive_file.replace('.zip','') + '_Archive_' + date + '.zip'
os.rename(archive_file,new_name)
os.remove(backup_file)
sys.exit()

print "Finished"
