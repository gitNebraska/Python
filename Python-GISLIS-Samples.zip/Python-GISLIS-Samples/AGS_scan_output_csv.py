import json,os,csv,getpass
import xml.etree.ElementTree as ET

### Set path to services directory in config-store folder
secrootdir = r'D:\arcgisserver\config-store\services'
###

secsearchdir = []
for subdir,dirs,files in os.walk(secrootdir):
    for file in files:
        if 'rlock' not in str(file):
            if 'MapServer.sec' in str(file):
                secsearchdir.append(os.path.join(subdir,file))

sec_dict={}
for each in secsearchdir:
    each_name = each[each.find('.')+1:-14]
    tree = ET.parse(each)
    root = tree.getroot()
    dict_list = []
    for child in root:
        for each in child:
            if each.attrib['isAllowed']=='true':
                dict_list.append(each.attrib['principal'])
    sec_dict[each_name]=dict_list

with open(r'D:\Users\{0}\Desktop\arcgisservice_settings.csv'.format(getpass.getuser()),mode='w') as sfile:
    sfile = csv.writer(sfile,delimiter=',',lineterminator='\n',quotechar='"',quoting=csv.QUOTE_MINIMAL)
    sfile.writerow(['path','Folder','serviceName','description','minInstancesPerNode','maxInstancesPerNode','FeatureService','Capabilities','Secured','Secure_Users','maxRecordCount','dateFieldsTimezoneID'])

rootdir = secrootdir
searchdir = []
fieldlist = ['serviceName','description','minInstancesPerNode','maxInstancesPerNode']
properties = ['maxRecordCount','dateFieldsTimezoneID']
extensions = ['typename','enabled','capabilities']
for subdir,dirs,files in os.walk(rootdir):
    for file in files:
        if 'rlock' not in str(file):
            if 'MapServer.json' in str(file):
                searchdir.append(os.path.join(subdir,file))

for each in searchdir:
    linelist = []
    linelist.append(each)
    folder_service = each[len(rootdir)+1:each.rfind('\\')-10]
    service_name = each[each.rfind('\\')+1:-15]
    folder = ''
    if '\\' in folder_service:
        folder = folder_service[:folder_service.find('\\')]
    else:
        folder = 'Root'
    linelist.append(folder)
    with open(each,'r') as f:
        d = json.load(f)
    for i in fieldlist:
        linelist.append('{0}'.format(str(d[i])))
    if len(d['extensions'])>6:
        for each in d['extensions'][6]:
            if each == 'enabled' and d['extensions'][6][each]=='true':
                linelist.append('TRUE')
                linelist.append('{0}'.format(d['extensions'][6]['capabilities']))
            elif each == 'enabled' and d['extensions'][6][each]=='false':
                linelist.append('')
                linelist.append('')
    else:
        linelist.append('')
        linelist.append('')
    if service_name in sec_dict.keys():
        linelist.append('TRUE')
        linelist.append(sec_dict[service_name])
    else:
        linelist.append('')
        linelist.append('')
    for each in d['properties']:
        if each in properties:
            linelist.append('{0}'.format(d['properties'][each]))
    with open(r'D:\Users\{0}\Desktop\arcgisservice_settings.csv',mode='a') as sfile:
        sfile = csv.writer(sfile,delimiter=',',lineterminator='\n',quotechar='"',quoting=csv.QUOTE_MINIMAL)
        sfile.writerow(linelist)
    
