import getpass
from arcgis.gis import GIS
from arcgis.mapping import WebMap

def defineGIS(user,password):
    return GIS(username=user,password=password)

def defineQuery(yn):
    if yn == 'y':
        query = input('Which username? ')
        return query

def searchAGOL(gis,url,query):
    if ',' in url:
        url = url.replace(' ','').split(',')
    for user in gis.users.search(query,max_users=1000):
        print("checking "+str(user['username']+"'s content..."))
        try:
            folder_list = user.folders
            i=0
            while i < len(folder_list):
                #print(folder_list[i]['title'])
                item_list = user.items(folder_list[i])
                j = 0
                while j < len(item_list):
                    if item_list[j]['type'] == 'Web Map':
                        wm_item = item_list[j]
                        web_map_obj = WebMap(wm_item)
                        for each in web_map_obj.layers:
                            if isinstance(url,list):
                                for thing in url:
                                    if 'url' in each:
                                        if thing.lower() in each["url"].lower():
                                            print("\t" + str(item_list[j]["title"]) + " uses "+str(each["url"]))
                            else:
                                if 'url' in each:
                                    if url.lower() in each["url"].lower():
                                        print("\t"+str(item_list[j]["title"]) + " uses "+str(each["url"]))
                        for k,v in web_map_obj.basemap.items():
                            if isinstance(url,list):
                                for thing in url:
                                    if str(k) == 'baseMapLayers':
                                        for dict in web_map_obj.basemap[k]:
                                            if 'styleUrl' in dict:
                                                if thing.lower() in dict['styleUrl'].lower():
                                                    print('\t{}: {} uses {} in its basemap'.format(thing.upper(),str(item_list[j]["title"]),str(dict['styleUrl'])))
                                            elif 'url' in dict:
                                                if thing.lower() in dict['url'].lower():
                                                    print('\t{}: {} uses {} in its basemap'.format(thing.upper(),str(item_list[j]["title"]),str(dict['url'])))
                            elif str(k) == 'baseMapLayers':
                                for dict in web_map_obj.basemap[k]:
                                    if 'styleUrl' in dict:
                                        if url.lower() in dict['styleUrl'].lower():
                                            print('\t{} uses {} in its basemap'.foramt(str(item_list[j]["title"]),str(dict['styleUrl'])))
                                    elif 'url' in dict:
                                        if url.lower() in dict['url'].lower():
                                            print('\t{} uses {} in its basemap'.format(str(item_list[j]["title"]),str(dict['url'])))
                    j+=1
                i+=1
        except:
            e = sys.exc_info()[1]
            f = sys.exc_info()[0]
            print('error on {} \n{}, {}'.format(str(user['username']),e,f))

user_info = defineGIS(input('User: '),getpass.getpass('Password: '))
url = input('Enter the URL (or part of URL) of a service\nto search for it in web maps (separate multiple by comma): ')
query = defineQuery(input('Would you like to query a specific user\'s content? (y/n): '))

searchAGOL(user_info,url,query)
